Venus is library about financial data.

event_init_stock是用来初始化stock数据库的。下载数据并创建相应的数据表。

event_record_stock是用来初始化录入数据，其效率较高。

event_flag_stock对股票进行标记。